package com.souvikbiswas.flutterfire_samples

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
